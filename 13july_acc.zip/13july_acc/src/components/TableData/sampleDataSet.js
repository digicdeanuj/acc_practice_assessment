dataList=[
    {
        "field_type":"number",
        "field_value":"1234",
        "field_label":"Emp ID",
        "field_options":[]
        
    },
    {
        "field_type":"text",
        "field_value":"Abc_xyz",
        "field_label":"Emp name",
        "field_options":[]
        
    },
    {
        "field_type":"date",
        "field_value":"1994-06-16",
        "field_label":"D.O.B.",
        "field_options":[]
    }
],
dataList=[
	{
		"field_type":"text",
		"field_value":"XXXX",
		"field_label":"Company Name",
		"field_options":[]
		
	},
	{
		"field_type":"number",
		"field_value":1111,
		"field_label":"Company ID",
		"field_options":[]
	},
	
	
	{
		"field_type":"dropdown",
		"field_value":"",
		"field_label":"Rating",
		"field_options":[
		{
					"lookupCd":1,
					"lookupValue":1,
					"isSelected":false
		},
		{
					"lookupCd":2,
					"lookupValue":2,
					"isSelected":true
		},
		{
					"lookupCd":3,
					"lookupValue":3,
					"isSelected":false
		},
		{
					"lookupCd":4,
					"lookupValue":4,
					"isSelected":false
		},
		{
					"lookupCd":5,
					"lookupValue":5,
					"isSelected":false
		}
		]
		
	},
	{
		"field_type":"textarea",
		"field_value":"not available",
		"field_label":"Comments",
		"field_options":[]
	}
	]